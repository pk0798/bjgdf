const offerLink = "https://tinyurl.com/36ccd8ry";
